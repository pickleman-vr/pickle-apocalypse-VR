PICKLE APOCALYPSE — BEGINNER PUBLISHING GUIDE

WHAT THIS IS
- index.html is the browser prototype.
- It is not a finished, tested Quest VR game yet. The current controls are mainly keyboard/mouse; proper Quest controller shooting and gorilla-style hand tracking still need development.

EASIEST WAY TO PUBLISH FROM A CHROMEBOOK (GitHub Pages)
You will need a GitHub account. If you're under 18, ask a parent/guardian to help create/manage the account and publish a public page.

1. On your Chromebook, open https://github.com and sign in.
2. Create a new repository named: pickle-apocalypse
3. Set it to Public, then create the repository.
4. In the repository, choose Add file -> Upload files.
5. Upload index.html from this folder (rename pickle_apocalypse_vr.html to index.html if using the original file).
6. Click Commit changes.
7. Open the repository's Settings -> Pages.
8. Under Build and deployment, choose Deploy from a branch.
9. Choose branch main and folder /(root), then Save.
10. Wait a few minutes. GitHub will show a website address similar to:
    https://YOUR-USERNAME.github.io/pickle-apocalypse/
11. Open that HTTPS address in the Meta Quest 3S Browser.
12. Test the normal page first. VR mode may not work correctly until VR controls are finished and tested.

IMPORTANT
- Do not share your password with anyone, including in chat.
- Public GitHub Pages means anyone with the link may view the game.
- This prototype loads Three.js from a public CDN, so the headset needs internet access.
- If the page does not load, check that the file is named exactly index.html and is in the repository root.
